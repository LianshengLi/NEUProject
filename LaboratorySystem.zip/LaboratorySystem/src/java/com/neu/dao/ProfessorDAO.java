/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.dao;

import com.neu.pojo.Assistant;
import com.neu.pojo.Professor;
import com.neu.pojo.Task;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author 41882
 */
public class ProfessorDAO {
    private static final SessionFactory sf = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session = null;
    private Session getSession(){
        if (session == null || !session.isOpen()){
            session = sf.openSession();
        }
        return session;
    }
   
    private void beginTransaction(){
        getSession().beginTransaction();
    }
    
    private void commit(){
        getSession().getTransaction().commit();
    }
    private void close(){
        getSession().close();
    }
    private void rollbackTransaction(){
        getSession().getTransaction().rollback();
    }
    public  void registerProfessor(Professor professor){
        try {
            beginTransaction();
            Session session = getSession();
            session.save(professor);
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
    }
    public boolean usernameIsExisted(String username){
        boolean state = false;
        try {
            beginTransaction();
            Query q = getSession().createQuery("FROM Professor p WHERE p.username= :username");
            q.setString("username", username);
            Professor professor= (Professor) q.uniqueResult();
            if (professor!=null) {
                state= true;
            }
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return state;
    }
    public Professor loginAuthentication(String username, String password){
        Professor professor = null;
        try {
            beginTransaction();
            Query q= getSession().createQuery("FROM Professor WHERE username= :username AND password= :password");
            q.setString("username", username);
            q.setString("password", password);
            professor = (Professor)q.uniqueResult();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return professor;
    }
    public Professor getProfessor(String professorUsername){
        Professor professor = null;
        try {
            beginTransaction();
            Query q1 = getSession().createQuery("from Professor p where p.username= :username");
            q1.setString("username", professorUsername);
            professor = (Professor) q1.uniqueResult();
            commit();
        }  catch (Exception e) {
            e.printStackTrace();
            rollbackTransaction();
        }finally {
            close();
        }
        return professor;
    }
    public Professor addAssistant(String professorUsername, int assistantID){
        Professor professor = null;
        try {
            beginTransaction();
            
            Query q1 = getSession().createQuery("from Professor p where p.username= :username");
            q1.setString("username", professorUsername);
            professor = (Professor) q1.uniqueResult();
//            Query q2 = getSession().createQuery("from Assistant a where a.assistantID= :assistantID");
//            q2.setInteger("assistantID", assistantId);
//            Assistant assistant = (Assistant) q2.uniqueResult();
//            System.out.println(professor);
//            System.out.println(assistant);
//            professor.getAssistants().add(assistant);
//            for(Assistant a: professor.getAssistants()){
//                System.out.println(a.getUsername());
//            }
            Query update = getSession().createQuery("update Assistant a set a.professor=:professor where a.assistantID=:assistantID");
            update.setParameter("professor", professor);
            update.setInteger("assistantID", assistantID);
            int i =update.executeUpdate();
            System.out.println(i);
            commit();
        } catch (Exception e) {
            e.printStackTrace();
            rollbackTransaction();
        }finally {
            close();
        }
        return professor;
    }
    public Professor addTask(String professorUsername, String taskMessage, int assistant1ID, int assistant2ID){
        Professor professor = null;
        try {
            beginTransaction();
            Query q1 = getSession().createQuery("from Professor p where p.username=:username");
            q1.setString("username", professorUsername);
            professor = (Professor) q1.uniqueResult();
            Query q2 = getSession().createQuery("from Assistant a where a.assistantID=:assistant1ID");
            q2.setInteger("assistant1ID", assistant1ID);
            Query q3 = getSession().createQuery("from Assistant a where a.assistantID=:assistant2ID");
            q3.setInteger("assistant2ID", assistant2ID);
            Assistant assistant1 = (Assistant) q2.uniqueResult();
            Assistant assistant2 = (Assistant) q3.uniqueResult();
            Task task = new Task();
            task.setProfessor(professor);
            task.setMessage(taskMessage);
            task.getAssistants().add(assistant1);
            task.getAssistants().add(assistant2);
            task.setStatus("Waiting Process");
            System.out.println(task);
            getSession().save(task);
            commit();
        } catch (Exception e) {
            e.printStackTrace();
            rollbackTransaction();
        }finally {
            close();
        }
        return professor;
    }
    public void deleteTask(String taskMessage){
        try {
            beginTransaction();
            Query q1 = getSession().createQuery("DELETE FROM Task t WHERE t.message=:taskMessage");
            q1.setString("taskMessage", taskMessage);
            q1.executeUpdate();
            commit();
        } catch (Exception e) {
            e.printStackTrace();
            rollbackTransaction();
        }finally {
            close();
        }
    }
}
