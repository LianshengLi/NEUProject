/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.dao;

import com.neu.pojo.Assistant;
import com.neu.pojo.Professor;
import com.neu.pojo.Task;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author 41882
 */
public class TaskDAO {
    private static final SessionFactory sf = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session = null;
    private Session getSession(){
        if (session == null || !session.isOpen()){
            session = sf.openSession();
        }
        return session;
    }
   
    private void beginTransaction(){
        getSession().beginTransaction();
    }
    
    private void commit(){
        getSession().getTransaction().commit();
    }
    private void close(){
        getSession().close();
    }
    private void rollbackTransaction(){
        getSession().getTransaction().rollback();
    }
    public List<Task> getProfessorTasks(String username){
        List<Task> tasks = new ArrayList<>();
        try {
            beginTransaction();
            Query q = getSession().createQuery("from Task t where t.professor.username=:username");
            q.setString("username", username);
            tasks = q.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return tasks;
    }
    public boolean contentIsExisted(String taskMessage){
        boolean state = false;
        try {
            beginTransaction();
            Query q = getSession().createQuery("FROM Task t WHERE t.message= :taskMessage");
            q.setString("taskMessage", taskMessage);
            Task task= (Task) q.uniqueResult();
            if (task!=null) {
                state= true;
            }
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return state;
    }
}
