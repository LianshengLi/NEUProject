/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.dao;

import com.neu.pojo.Assistant;
import com.neu.pojo.Professor;
import com.neu.pojo.Task;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author 41882
 */
public class AssistantDAO {
    private static final SessionFactory sf = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session = null;
    private Session getSession(){
        if (session == null || !session.isOpen()){
            session = sf.openSession();
        }
        return session;
    }
   
    private void beginTransaction(){
        getSession().beginTransaction();
    }
    
    private void commit(){
        getSession().getTransaction().commit();
    }
    private void close(){
        getSession().close();
    }
    private void rollbackTransaction(){
        getSession().getTransaction().rollback();
    }
    public int registerAssistant(Assistant assistant){
        int result = 0;
        try {
            beginTransaction();
            Session session = getSession();
            session.save(assistant);
            commit();
            result = 1;
        } catch (HibernateException e) {
             
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return result;
    }
    public boolean usernameIsExisted(String username){
        boolean state = false;
        try {
            beginTransaction();
            Query q = getSession().createQuery("FROM Assistant a WHERE a.username= :username");
            q.setString("username", username);
            Assistant assistant= (Assistant) q.uniqueResult();
            commit();
            if (assistant!=null) {
                state= true;
            }
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return state;
    }
    public boolean loginAuthentication(String username, String password){
        boolean state = false;
        try {
            beginTransaction();
            Query q= getSession().createQuery("FROM Assistant WHERE username= :username AND password= :password");
            q.setString("username", username);
            q.setString("password", password);
            Assistant assistant = (Assistant)q.uniqueResult();
            if (assistant!=null) {
                state = true;
            }
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return state;
    }
    public Assistant getAssistant(String assistantUsername){
        Assistant assistant = null;
        try {
            beginTransaction();
            Query q1 = getSession().createQuery("from Assistant a where a.username= :username");
            q1.setString("username", assistantUsername);
            assistant = (Assistant) q1.uniqueResult();
            commit();
        }  catch (Exception e) {
            e.printStackTrace();
            rollbackTransaction();
        }finally {
            close();
        }
        return assistant;
    }
    public List<Assistant> getAllAssistants(){
        List<Assistant> assistants = new ArrayList<>();
        try {
            beginTransaction();
            Query q = getSession().createQuery("from Assistant  ");
            assistants = q.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return assistants;
    }
    public List<Assistant> getProfessorAssistants(String username){
        List<Assistant> assistants = new ArrayList<>();
        try {
            beginTransaction();
            Query q = getSession().createQuery("from Assistant a where a.professor.username=:username");
            q.setString("username", username);
            assistants = q.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return assistants;
    }
    public List<Task> getAssistantTasks(String username){
        List<Task> tasks = new ArrayList<>();
        try {
            beginTransaction();
            Criteria crit = getSession().createCriteria(Task.class);
            Criteria assistantCrit = crit.createCriteria("assistants");
            assistantCrit.add(Restrictions.eq("username", username));
            tasks = crit.list();
//            Query q1 = getSession().createQuery("from Assistant a where a.username=:username");
//            q1.setString("username", username);
//            Assistant a = (Assistant) q1.uniqueResult();
//            Query q2 = getSession().createSQLQuery("select a.message from tasktable a,assistanttable b,t_task_assistant c"+
//                    "where a.id=b.t_id and b.a_id=:assistantID");
//            q2.setInteger("assistantID", (int) a.getAssistantID());
//            taskMessages = q2.list();
            commit();
            
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return tasks;
    }
    public void processTask(String message){
        try {
            beginTransaction();
            Query q = getSession().createQuery("UPDATE Task t SET t.status=:status WHERE t.message=:message");
            q.setParameter("status", "finished");
            q.setParameter("message", message);
            q.executeUpdate();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
    }
}
