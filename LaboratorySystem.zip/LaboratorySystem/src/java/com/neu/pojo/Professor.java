/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author 41882
 */
public class Professor {
    private long professorID;
    private String fname;
    private String lname;
    private String email;
    private String username;
    private String password;
    private Set<Assistant> assistants = new HashSet<>();
    private Set<Task> tasks = new HashSet<>();

    public Professor(long professorID, String fname, String lname, String email, String username, String password, Set<Assistant> assistants, Set<Task> tasks) {
        this.professorID = professorID;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.username = username;
        this.password = password;
        this.assistants = assistants;
        this.tasks = tasks;
    }


    public Professor() {
    }

    public long getProfessorID() {
        return professorID;
    }

    public void setProfessorID(long professorID) {
        this.professorID = professorID;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Assistant> getAssistants() {
        return assistants;
    }

    public void setAssistants(Set<Assistant> assistants) {
        this.assistants = assistants;
    }

    public Set<Task> getTasks() {
        return tasks;
    }

    public void setTasks(Set<Task> tasks) {
        this.tasks = tasks;
    }

    @Override
    public String toString() {
        return "Professor{" + "professorID=" + professorID + ", username=" + username + '}';
    }

    
}
