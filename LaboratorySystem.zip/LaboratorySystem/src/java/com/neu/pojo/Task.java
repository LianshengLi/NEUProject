/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author 41882
 */
public class Task {
    private long taskID; 
    private String message;
    private String status;
    private Professor professor;
    private Set<Assistant> assistants = new HashSet<>();
    public Task() {
    }

    public Task(long taskID, String message, Professor professor, Set<Assistant> assistants, String status) {
        this.taskID = taskID;
        this.message = message;
        this.professor = professor;
        this.assistants = assistants;
        this.status = status;
    }

    public long getTaskID() {
        return taskID;
    }

    public void setTaskID(long taskID) {
        this.taskID = taskID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Set<Assistant> getAssistants() {
        return assistants;
    }

    public void setAssistants(Set<Assistant> assistants) {
        this.assistants = assistants;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Content: "+message+" assistants= " + assistants+" status: "+status;
    }

}
