/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author 41882
 */
public class Assistant {
    private long assistantID;
    private String fname;
    private String lname;
    private String email;
    private String username;
    private String password;
    private Professor professor;
    private Set<Task> tasks = new HashSet<>();

    public Assistant(long assistantID, String fname, String lname, String email, String username, String password, Professor professor, Set<Task> tasks) {
        this.assistantID = assistantID;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.username = username;
        this.password = password;
        this.professor = professor;
        this.tasks = tasks;
    }

    public Assistant() {
    }

    public long getAssistantID() {
        return assistantID;
    }

    public void setAssistantID(long assistantID) {
        this.assistantID = assistantID;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public Set<Task> getTasks() {
        return tasks;
    }

    public void setTasks(Set<Task> tasks) {
        this.tasks = tasks;
    }

    @Override
    public String toString() {
        return username+"(AssistantID: "+assistantID+")";
    }

}
