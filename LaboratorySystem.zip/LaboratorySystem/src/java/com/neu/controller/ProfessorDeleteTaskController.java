/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.dao.AssistantDAO;
import com.neu.dao.ProfessorDAO;
import com.neu.dao.TaskDAO;
import com.neu.pojo.Professor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author 41882
 */
public class ProfessorDeleteTaskController extends AbstractController {
    ProfessorDAO professorDAO;
    AssistantDAO assistantDAO;
    TaskDAO taskDAO;
    public ProfessorDeleteTaskController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        professorDAO=(ProfessorDAO) getApplicationContext().getBean("professordao");
        assistantDAO=(AssistantDAO) getApplicationContext().getBean("assistantdao");        
        taskDAO= (TaskDAO) getApplicationContext().getBean("taskdao");
        String taskMessage = request.getParameter("taskMessage");
        String professorUsername = request.getParameter("professorUsername");
        ModelAndView mv = new ModelAndView("ProfessorWorkArea");
        professorDAO.deleteTask(taskMessage);
        Professor professor = professorDAO.getProfessor(professorUsername);
        mv.addObject("professor", professor);
        mv.addObject("professorAssistants", assistantDAO.getProfessorAssistants(professor.getUsername()));
        mv.addObject("professorTasks",taskDAO.getProfessorTasks(professor.getUsername()));
        return mv;
    }
    
}
