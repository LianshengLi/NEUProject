/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.dao.AssistantDAO;
import com.neu.dao.ProfessorDAO;
import com.neu.pojo.Assistant;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

/**
 *
 * @author 41882
 */
public class AssistantRegisterController extends SimpleFormController {
    AssistantDAO assistantDAO;
    public AssistantRegisterController() {
        //Initialize controller properties here or 
        //in the Web Application Context

        setCommandClass(Assistant.class);
        setCommandName("assistant");
        setSuccessView("AssistantWorkArea");
        setFormView("AssistantRegister");
    }
    
    @Override
    protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
            BindException errors) throws Exception {
        assistantDAO=(AssistantDAO) getApplicationContext().getBean("assistantdao");
        Assistant assistant = (Assistant) command;
        if (assistantDAO.usernameIsExisted(assistant.getUsername())==true) {
            JOptionPane.showMessageDialog(null, "Username Existed");
            return new ModelAndView("redirect: assistantregister.htm");
        }
        assistantDAO.registerAssistant(assistant);
        return new ModelAndView(getSuccessView(),"assistant",assistant);
    }
}
