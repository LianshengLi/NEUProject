/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.dao.AssistantDAO;
import com.neu.pojo.Assistant;
import com.neu.pojo.Task;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

/**
 *
 * @author 41882
 */
public class AssistantLoginController extends SimpleFormController {
    AssistantDAO assistantDAO;
    public AssistantLoginController() {
        //Initialize controller properties here or 
        //in the Web Application Context

        setCommandClass(Assistant.class);
        setCommandName("assistant");
        setSuccessView("AssistantWorkArea");
        setFormView("AssistantLogin");
    }
    
    @Override
    protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
            BindException errors) throws Exception {
        ModelAndView mv = new ModelAndView(getSuccessView());
        assistantDAO=(AssistantDAO) getApplicationContext().getBean("assistantdao");
        Assistant assistant = (Assistant) command;
        if (assistantDAO.loginAuthentication(assistant.getUsername(), assistant.getPassword())==true) {
            mv.addObject("assistant", assistant);
            List<Task> assistantTasks = assistantDAO.getAssistantTasks(assistant.getUsername());
            mv.addObject("assistantTasks", assistantTasks);
            return mv;
        }
        JOptionPane.showMessageDialog(null, "Wrong Username or Password ");
        return new ModelAndView("redirect: assistantlogin.htm");
    }
}
