/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.dao.AssistantDAO;
import com.neu.dao.ProfessorDAO;
import com.neu.dao.TaskDAO;
import com.neu.pojo.Assistant;
import com.neu.pojo.Professor;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

/**
 *
 * @author 41882
 */
public class ProfessorRegisterController extends SimpleFormController {
    ProfessorDAO professorDAO;
    AssistantDAO assistantDAO;
    TaskDAO taskDAO;
    public ProfessorRegisterController() {
        //Initialize controller properties here or 
        //in the Web Application Context

        setCommandClass(Professor.class);
        setCommandName("professor");
        setSuccessView("ProfessorWorkArea");
        setFormView("ProfessorRegister");
    }
    
    @Override
    protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
            BindException errors) throws Exception {
        ModelAndView mv = new ModelAndView(getSuccessView());
        professorDAO=(ProfessorDAO) getApplicationContext().getBean("professordao");
        assistantDAO=(AssistantDAO) getApplicationContext().getBean("assistantdao");
        taskDAO = (TaskDAO) getApplicationContext().getBean("taskdao");
        Professor professor = (Professor) command;
        if (professorDAO.usernameIsExisted(professor.getUsername())==true) {
            JOptionPane.showMessageDialog(null, "Username Existed");
            return new ModelAndView("redirect: professorregister.htm");
        }
        professorDAO.registerProfessor(professor);
        List<Assistant> professorAssistants =assistantDAO.getProfessorAssistants(professor.getUsername());
        mv.addObject("professor", professor);
        mv.addObject("professorAssistants", professorAssistants);
        mv.addObject("professorTasks",taskDAO.getProfessorTasks(professor.getUsername()));
        return mv;
    }
}
