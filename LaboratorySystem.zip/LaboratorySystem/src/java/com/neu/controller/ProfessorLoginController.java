/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.dao.AssistantDAO;
import com.neu.dao.ProfessorDAO;
import com.neu.dao.TaskDAO;
import com.neu.pojo.Professor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

/**
 *
 * @author 41882
 */
public class ProfessorLoginController extends SimpleFormController {
    ProfessorDAO professorDAO;
    AssistantDAO assistantDAO;
    TaskDAO taskDAO;
    public ProfessorLoginController() {
        //Initialize controller properties here or 
        //in the Web Application Context

        setCommandClass(Professor.class);
        setCommandName("professor");
        setSuccessView("ProfessorWorkArea");
        setFormView("ProfessorLogin");
    }
    @Override
    protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
            BindException errors) throws Exception {
        ModelAndView mv = new ModelAndView(getSuccessView());
        professorDAO=(ProfessorDAO) getApplicationContext().getBean("professordao");
        assistantDAO=(AssistantDAO) getApplicationContext().getBean("assistantdao");
        taskDAO=(TaskDAO) getApplicationContext().getBean("taskdao");
        Professor professor = (Professor) command;
        System.out.println(professorDAO.loginAuthentication(professor.getUsername(), professor.getPassword()));
        if (professorDAO.loginAuthentication(professor.getUsername(), professor.getPassword())!=null) {
            mv.addObject("professor", professorDAO.loginAuthentication(professor.getUsername(), professor.getPassword()));
            assistantDAO.getProfessorAssistants(professor.getUsername());
            mv.addObject("professorAssistants", assistantDAO.getProfessorAssistants(professor.getUsername()));
            mv.addObject("professorTasks",taskDAO.getProfessorTasks(professor.getUsername()));
            return mv;
        }
        JOptionPane.showMessageDialog(null, "Wrong Username or Password ");
        return new ModelAndView("redirect: professorlogin.htm");
    }   

}
