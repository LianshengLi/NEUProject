/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.dao.AssistantDAO;
import com.neu.pojo.Assistant;
import com.neu.pojo.Task;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author 41882
 */
public class AssistantProcessTaskController extends AbstractController {
    AssistantDAO assistantDAO;
    public AssistantProcessTaskController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        assistantDAO=(AssistantDAO) getApplicationContext().getBean("assistantdao");
        ModelAndView mv = new ModelAndView("AssistantWorkArea");
        String assistantUsername = request.getParameter("assistantUsername");
        String message = request.getParameter("message");
        System.out.println("----------------------taskmessage is"+message);
        assistantDAO.processTask(message);
        Assistant assistant = assistantDAO.getAssistant(assistantUsername);
        mv.addObject("assistant", assistant);
        List<Task> assistantTasks = assistantDAO.getAssistantTasks(assistantUsername);
        mv.addObject("assistantTasks", assistantTasks);
        return mv;
    }
    
}
