/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.controller;

import com.neu.dao.AssistantDAO;
import com.neu.dao.ProfessorDAO;
import com.neu.dao.TaskDAO;
import com.neu.pojo.Professor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author 41882
 */
public class ProfessorAddTaskController extends AbstractController {
    ProfessorDAO professorDAO;
    AssistantDAO assistantDAO;
    TaskDAO taskDAO;
    public ProfessorAddTaskController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        professorDAO=(ProfessorDAO) getApplicationContext().getBean("professordao");
        assistantDAO=(AssistantDAO) getApplicationContext().getBean("assistantdao");        
        taskDAO= (TaskDAO) getApplicationContext().getBean("taskdao");
        ModelAndView mv = new ModelAndView("ProfessorWorkArea");
        String taskMessage = request.getParameter("taskMessage");
        String professorUsername = request.getParameter("professorUsername");
        int assistant1ID = Integer.parseInt(request.getParameter("assistant1ID"));
        int assistant2ID = Integer.parseInt(request.getParameter("assistant2ID"));
        System.out.println(taskMessage);
        System.out.println(professorUsername);
        if (taskDAO.contentIsExisted(taskMessage)==true) {
            JOptionPane.showMessageDialog(null, "TaskExisted");
            Professor professor = professorDAO.getProfessor(professorUsername);
            mv.addObject("professor", professor);
            mv.addObject("professorAssistants", assistantDAO.getProfessorAssistants(professor.getUsername()));
            mv.addObject("professorTasks",taskDAO.getProfessorTasks(professor.getUsername()));
            return mv; 
        }
        Professor professor = professorDAO.addTask(professorUsername, taskMessage,assistant1ID,assistant2ID);
        mv.addObject("professor", professor);
        mv.addObject("professorAssistants", assistantDAO.getProfessorAssistants(professor.getUsername()));
        mv.addObject("professorTasks",taskDAO.getProfessorTasks(professor.getUsername()));
        return mv;
    }
    
}
