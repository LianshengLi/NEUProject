/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.CustomerRole;


import Business.Enterprise.Enterprise;
import Business.Line.Line;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.SubwaySystem;
import Business.Ticket.Ticket;
import Business.Ticket.TicketDirectory;
import Business.UserAccount.CustomerAccount;
import Business.UserAccount.UserAccount;
import java.awt.CardLayout;
import java.awt.Component;
import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import Business.*;
import Business.Data.DataGenerator;
import Business.Data.DataReader;
import java.util.ArrayList;
/**
 *
 * @author lizhenhao
 */
public class CreateTicketJPanel extends javax.swing.JPanel {

    private JPanel userProcessContainer;
    private TicketDirectory td;
    private CustomerAccount account;
    private Enterprise enterprise;
    DataReader ticketReader;

    /**
     * Creates new form CreateTicketJPanel
     */
    public CreateTicketJPanel(JPanel userProcessContainer, CustomerAccount account, Enterprise enterprise) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.account = account;
        this.enterprise = enterprise;
     
            popData();
 
        //popNetworkComboBox();
    }
    
   
    
    public void popData() {

        DefaultTableModel model = (DefaultTableModel) userJTable.getModel();

        model.setRowCount(0);
        for (Line line : enterprise.getLineList().getLineList()) {
            if(!line.getStatus().equals("Normal")) {
                continue;    
            }
                    Object row[] = new Object[7];
                    row[0] = line;
                    String result1 = line.getStop1().getStatus();
                    row[1] = line.getStop1()+"("+result1+")";
                      String result2 = line.getStop2().getStatus();
                    row[2] = line.getStop2()+"("+result2+")";
                    String result3 = line.getStop3().getStatus();
                    row[3] = line.getStop3()+"("+result3+")";
                    String result4 = line.getStop4().getStatus();
                    row[4] = line.getStop4()+"("+result4+")";
                    String result5 = line.getStop5().getStatus();
                    row[5] = line.getStop5()+"("+result5+")";
                    row[6] = line.getPrice();
                    
                   model.addRow(row);
                }

    }
    
    public void initialize() throws IOException {
        ArrayList<Integer> lineNum = new ArrayList<Integer>();
        for (Line line : enterprise.getLineList().getLineList()) {
            if(!(line.getStatus().equals("Normal"))
                 ||!(line.getStop1().getStatus().equals("Normal"))
                 ||!(line.getStop2().getStatus().equals("Normal"))
                 ||!(line.getStop3().getStatus().equals("Normal"))
                 ||!(line.getStop4().getStatus().equals("Normal"))
                 ||!(line.getStop5().getStatus().equals("Normal"))) {
                continue;    
            }
            else {
                int idx = enterprise.getLineList().getLineList().indexOf(line);
                lineNum.add(idx);
            }
        }
        //int lineNum = enterprise.getLineList().getLineList().size();
        String uName = account.getUsername();
        DataGenerator generator = DataGenerator.getInstance(lineNum, uName);
        ticketReader = new DataReader(generator.getTicketFilePath());
    }    
    
    private void readData() throws IOException{
        String[] row;
        //while((row = userReader.getNextRow()) != null ){
        //    generateUser(row);
        //}
        while((row = ticketReader.getNextRow()) != null ){
            Ticket ticket = generateTicket(row);
        }
        
        //runAnalysis();
    }
    
    private Ticket generateTicket(String[] row){
        int ticketId = Integer.parseInt(row[0]);
        //int userId = Integer.parseInt(row[3]);
        String date = row[2];
        int lineId = Integer.parseInt(row[1]);
        String comment = row[4];
        Line line = enterprise.getLineList().getLineList().get(lineId);
        //Ticket t = account.getCustomer().getTicketDirectory().AddTicket(line);
        Ticket ticket = new Ticket();
        ticket.setLine(line);
        account.getCustomer().getTicketDirectory().getTicketList().add(ticket);
        //DataStore.getInstance().getTickets().put(ticketId,t);
        //Map<Integer,User> users = DataStore.getInstance().getUsers();
        //if(users.containsKey(userId))
        //    users.get(userId).getTicket().add(t);
        return ticket;
    }    
    
    
    /*
    public void popNetworkComboBox() {
        networkJComboBox.removeAllItems();

        for (Network network : system.getNetworkList()) {
            networkJComboBox.addItem(network);
        }
    }
    
    public void popEnterpriseComboBox(Network network){
        enterpriseJComboBox.removeAllItems();
        
        for (Enterprise enterprise : network.getEnterpriseDirectory().getEnterpriseList()){
            enterpriseJComboBox.addItem(enterprise);
        }
    }
    
    private void popLineComboBox(Enterprise enterprise){
        lineJComboBox.removeAllItems();
        for (Line line : enterprise.getLineList().getLineList()){
            lineJComboBox.addItem(line);
        }
    } 
    */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        userJTable = new javax.swing.JTable();
        backjButton1 = new javax.swing.JButton();
        createUserJButton = new javax.swing.JButton();
        popBtn = new javax.swing.JButton();

        setBackground(new java.awt.Color(204, 153, 0));

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 3, 18)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/png/income.png"))); // NOI18N
        jLabel6.setText("Book Ticket");

        userJTable.setFont(new java.awt.Font("Lucida Grande", 1, 12)); // NOI18N
        userJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Line", "Stop1", "Stop2", "Stop3", "Stop4", "Stop5", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(userJTable);

        backjButton1.setBackground(new java.awt.Color(204, 204, 204));
        backjButton1.setFont(new java.awt.Font("Lucida Grande", 1, 12)); // NOI18N
        backjButton1.setText("<< Back");
        backjButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backjButton1ActionPerformed(evt);
            }
        });

        createUserJButton.setBackground(new java.awt.Color(204, 204, 204));
        createUserJButton.setFont(new java.awt.Font("Lucida Grande", 1, 12)); // NOI18N
        createUserJButton.setText("Book");
        createUserJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createUserJButtonActionPerformed(evt);
            }
        });

        popBtn.setFont(new java.awt.Font("Lucida Grande", 1, 12)); // NOI18N
        popBtn.setText("Generate History Data Randomly");
        popBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                popBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(backjButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(584, 584, 584)
                            .addComponent(createUserJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 786, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(popBtn)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backjButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(createUserJButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(popBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents
    /*    */
    private void backjButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backjButton1ActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_backjButton1ActionPerformed

    private void createUserJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createUserJButtonActionPerformed
       int selectedRow = userJTable.getSelectedRow();
        
       if (selectedRow >= 0) {
                Line line=(Line)userJTable.getValueAt(selectedRow, 0);
                if(!(line.getStop1().getStatus().equals("Normal"))
                 ||!(line.getStop2().getStatus().equals("Normal"))
                 ||!(line.getStop3().getStatus().equals("Normal"))
                 ||!(line.getStop4().getStatus().equals("Normal"))
                 ||!(line.getStop5().getStatus().equals("Normal"))){
                 JOptionPane.showMessageDialog(null, "This line is temporary suspension because of the maintenance.");
                 return;
                }
                //System.out.println(line.getName());
                Ticket ticket = new Ticket();
                ticket.setLine(line);
                account.getCustomer().getTicketDirectory().getTicketList().add(ticket);
                //Ticket t=account.getCustomer().getTicketDirectory().AddTicket(line);
          JOptionPane.showMessageDialog(null, "Book the ticket successfully!!");
          
            
        } else {
            JOptionPane.showMessageDialog(null, "Please select a Row!!");
            
       }

        //popData();
    }//GEN-LAST:event_createUserJButtonActionPerformed

    private void popBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_popBtnActionPerformed
        try {
            initialize();
            readData();
        } catch (IOException ex) {
            Logger.getLogger(CreateTicketJPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_popBtnActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backjButton1;
    private javax.swing.JButton createUserJButton;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton popBtn;
    private javax.swing.JTable userJTable;
    // End of variables declaration//GEN-END:variables
}
