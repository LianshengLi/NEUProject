/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Line.Line;
import Business.Stop.Stop;
import Business.UserAccount.UserAccount;

/**
 *
 * @author 41882
 */
public class MaintenanceRequest {
    private UserAccount sender;
    private UserAccount receiver;
    //private String work;
    private Stop stop;
    private String status;
    private String requestInformation;
    //private int requestID;
    //private static int counter=0;
    public MaintenanceRequest(){
        //requestID = counter;
        //++counter;
    }
    public UserAccount getSender() {
        return sender;
    }

    public void setSender(UserAccount sender) {
        this.sender = sender;
    }

    public UserAccount getReceiver() {
        return receiver;
    }

    public void setReceiver(UserAccount receiver) {
        this.receiver = receiver;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Stop getStop() {
        return stop;
    }

    public void setStop(Stop stop) {
        this.stop = stop;
    }

    public String getRequestInformation() {
        return requestInformation;
    }

    public void setRequestInformation(String requestInformation) {
        this.requestInformation = requestInformation;
    }
    
    @Override
    public String toString() {
        return requestInformation;
}

    
}
