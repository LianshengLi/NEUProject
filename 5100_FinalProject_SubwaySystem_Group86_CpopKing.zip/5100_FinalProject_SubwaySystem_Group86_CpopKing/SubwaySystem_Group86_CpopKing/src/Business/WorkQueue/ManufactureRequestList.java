/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author 41882
 */
public class ManufactureRequestList {
    private ArrayList<ManufactureRequest> manufactureRequestList;
    
    public ManufactureRequestList(){
        manufactureRequestList = new ArrayList<ManufactureRequest>();
    }

    public ArrayList<ManufactureRequest> getManufactureRequestList() {
        return manufactureRequestList;
    }

    public void setManufactureRequestList(ArrayList<ManufactureRequest> manufactureRequestList) {
        this.manufactureRequestList = manufactureRequestList;
    }
    
}
