/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author 41882
 */
public class MaintenanceRequestList {
    private ArrayList<MaintenanceRequest> maintenanceRequestList;
    public MaintenanceRequestList(){
        maintenanceRequestList = new ArrayList<MaintenanceRequest>();
    }

    public ArrayList<MaintenanceRequest> getMaintenanceRequestList() {
        return maintenanceRequestList;
    }

    public void setMaintenanceRequestList(ArrayList<MaintenanceRequest> maintenanceRequestList) {
        this.maintenanceRequestList = maintenanceRequestList;
    }


    


    
}
