/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Enterprise.Enterprise;
import Business.Line.Line;
import Business.UserAccount.UserAccount;

/**
 *
 * @author 41882
 */
public class ManufactureRequest {
    private Enterprise sender;
    private Enterprise receiver;
    private Line line;
    private int ID;
    public ManufactureRequest(){
        ID+=ID;
        
    }

    public Enterprise getSender() {
        return sender;
    }

    public void setSender(Enterprise sender) {
        this.sender = sender;
    }

    public Enterprise getReceiver() {
        return receiver;
    }

    public void setReceiver(Enterprise receiver) {
        this.receiver = receiver;
    }



    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }
     @Override
    public String toString() {
        return String.valueOf(ID);
    }
}
