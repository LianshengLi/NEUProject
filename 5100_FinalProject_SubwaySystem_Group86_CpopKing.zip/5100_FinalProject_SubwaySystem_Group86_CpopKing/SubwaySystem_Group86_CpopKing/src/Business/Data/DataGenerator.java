/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Data;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
/**
 *
 * @author lizhenhao
 */
public class DataGenerator {
    
    private static DataGenerator instance;
    
    private FileWriter writer;
    private File file;
    
    private final Random rand;
    
    private final int userIdsRange;
    private final int ticketIdsRange;
    private final int dateRange;
    private final int lineIdsRange;
    private final int ratingRange;
    private int lineNum;
    private String uName;
    private ArrayList<Integer> lineID;

    private final String TICKET_HEADER = "Ticket-Id,Line-id,Date,User-Id, Comment";
    //private final String USER_HEADER = "User-Id,First-Name,Last-Name,Rating";
    private final String LINE_BREAK = "\n";
    
    //private final String USER_CAT_PATH = "./UserCatalogue.csv";
    private final String TICKET_FILE_PATH = "./TicketData.csv";    
    
    private DataGenerator(ArrayList<Integer> lineID, String uName) throws IOException {
                
        rand = new Random();
        
        userIdsRange = 10;
        ticketIdsRange = 50;
        dateRange = 31;
        lineIdsRange = 40;
        ratingRange = 300;
        this.lineNum = lineNum;
        this.uName = uName;
        this.lineID = lineID;
        
        generateTicketFile();
        //generateUserFile();
        
    }
    
    public static DataGenerator getInstance(ArrayList<Integer> lineID, String uName) throws IOException{
        if(instance == null)
        {
            instance = new DataGenerator(lineID, uName);
        }
        return instance;
    }
    
    private void generateTicketFile() throws IOException{
        //generate Order file
        try {
            file = new File(TICKET_FILE_PATH);
            if(file.exists()){
                file.delete();
            }
            file.createNewFile();
            System.out.println("New Comment File Created");
            writer = new FileWriter(file);
        
            writer.append(TICKET_HEADER);
            writer.append(LINE_BREAK);
            
            generateTicketColumns();   
            
        }finally{
            try {
                writer.flush();
                writer.close();
            } catch (IOException e) {
                System.out.println("Error while flushing/closing fileWriter !!!");
                e.printStackTrace();
            }
        }
        
        
        
    }
    
    private void generateTicketColumns() throws IOException{
        //nt lineId = 0;
        //int enterperiseId = rand.nextInt(userIdsRange);
        int ticketId = 0;
        //the loop for orders
   
        while(ticketId < ticketIdsRange) {
            //int iterations = rand.nextInt(10);
            
            //while(iterations > 0){
                Date currentTime = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' HH:mm:ss z");
                String dateString = formatter.format(currentTime);
                //int UserId = rand.nextInt(userIdsRange);
                int index=(int)(Math.random()*lineID.size());
                int l = lineID.get(index);
                //lineId = rand.nextInt(lineNum);
                String comment = "Regular one way trip ticket Id "+ticketId;
                
                String column = ticketId+","+l+","+dateString+","+uName+","+comment;
                
                writer.append(column);
                writer.append(LINE_BREAK);
                
                ticketId++;
                //iterations--;
            //}
            
            //enterpriseId = rand.nextInt(enterpriseRange);
            //lineId++;
        }
        
    }
    
    public String getTicketFilePath(){
        return TICKET_FILE_PATH;
    }    
    
    
}
