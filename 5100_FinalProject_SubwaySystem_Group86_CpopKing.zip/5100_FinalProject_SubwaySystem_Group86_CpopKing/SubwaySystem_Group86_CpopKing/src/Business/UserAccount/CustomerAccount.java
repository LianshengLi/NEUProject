/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount;

import Business.Customer.Customer;
import Business.Enterprise.Enterprise;
import Business.WorkQueue.WorkQueue;
import javax.swing.JPanel;
import userinterface.CustomerRole.CustomerWorkAreaJPanel;

/**
 *
 * @author zhouzhou
 */
public class CustomerAccount {
    private String username;
    private String password;
    private Customer customer;
    private WorkQueue workQueue;
    

    public CustomerAccount() {
        workQueue = new WorkQueue();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public WorkQueue getWorkQueue() {
        return workQueue;
    }

    public void setWorkQueue(WorkQueue workQueue) {
        this.workQueue = workQueue;
    }
    
    public JPanel createWorkArea(JPanel userProcessContainerJPanel, CustomerAccount account, Enterprise enterprise){
        return new CustomerWorkAreaJPanel(userProcessContainerJPanel,account,  enterprise);
    }
      @Override
    public String toString() {
        return username;
    }
}
