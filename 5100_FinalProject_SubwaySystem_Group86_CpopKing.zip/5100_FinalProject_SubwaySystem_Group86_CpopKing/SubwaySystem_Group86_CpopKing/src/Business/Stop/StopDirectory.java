/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Stop;

import java.util.ArrayList;

/**
 *
 * @author zhouzhou
 */
public class StopDirectory {
     private ArrayList<Stop> stopList;
    public StopDirectory(){
        stopList = new ArrayList<Stop>();
    }

    public ArrayList<Stop> getStopList() {
        return stopList;
    }
    public Stop createStop(String name){
        Stop stop =  new Stop(name);
        stopList.add(stop);
        return stop;
    }
   
}
