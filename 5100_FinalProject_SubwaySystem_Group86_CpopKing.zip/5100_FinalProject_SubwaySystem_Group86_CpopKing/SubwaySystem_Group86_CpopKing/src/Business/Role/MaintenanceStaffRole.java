/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.SubwaySystem;
import Business.Enterprise.Enterprise;
import Business.Organization.MaintenanceOrganization;
import Business.Organization.Organization;

import Business.UserAccount.UserAccount;
import userinterface.MaintenanceStaffRole.MaintenanceStaffWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public class MaintenanceStaffRole extends Role {

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, SubwaySystem business) {
        return new MaintenanceStaffWorkAreaJPanel(userProcessContainer, account, (MaintenanceOrganization)organization, business);
    }
    
}
