 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Customer.CustomerDirectory;
import Business.Employee.EmployeeDirectory;
import Business.Line.LineDirectory;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;
import Business.Rating.RatingDirectory;
import Business.Stop.StopDirectory;
import Business.UserAccount.CustomerAccountDirectory;
import Business.UserAccount.UserAccountDirectory;
import Business.WorkQueue.ManufactureRequestList;

/**
 *
 * @author MyPC1
 */
public abstract class Enterprise extends Organization{
    
   private EnterpriseType enterpriseType;
    private OrganizationDirectory organizationDirectory;
    private LineDirectory lineList;
    private StopDirectory stopList;
    private CustomerDirectory customerDirectory;
    private CustomerAccountDirectory customerAccountDirectory;
    private RatingDirectory ratingDirectory;
    private Network network;
    private ManufactureRequestList manufactureRequestList;
    private float environment;
    private float service;
    private float speed;
    private float fashion;
    private float pricing;
    private float revenue;
    
    public enum EnterpriseType{
        Subway("Subway"),
        Supplier("Supplier");
        
        private String value;
        
        private EnterpriseType(String value){
            this.value=value;
        }
        public String getValue() {
            return value;
        }
        @Override
        public String toString(){
        return value;
    }
    }

    public ManufactureRequestList getManufactureRequestList() {
        return manufactureRequestList;
    }

    public void setManufactureRequestList(ManufactureRequestList manufactureRequestList) {
        this.manufactureRequestList = manufactureRequestList;
    }


    
    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public LineDirectory getLineList() {
        return lineList;
    }

    public void setLineList(LineDirectory lineList) {
        this.lineList = lineList;
    }

    public StopDirectory getStopList() {
        return stopList;
    }

    public void setStopList(StopDirectory stopList) {
        this.stopList = stopList;
    }
     public CustomerDirectory getCustomerDirectory() {
        return customerDirectory;
    }

    public void setCustomerDirectory(CustomerDirectory customerDirectory) {
        this.customerDirectory = customerDirectory;
    }

    public CustomerAccountDirectory getCustomerAccountDirectory() {
        return customerAccountDirectory;
    }

    public void setCustomerAccountDirectory(CustomerAccountDirectory customerAccountDirectory) {
        this.customerAccountDirectory = customerAccountDirectory;
    }
    

    public EnterpriseType getEnterpriseType() {
        return enterpriseType;
    }

    public void setEnterpriseType(EnterpriseType enterpriseType) {
        this.enterpriseType = enterpriseType;
    }

    public RatingDirectory getRatingDirectory() {
        return ratingDirectory;
    }

    public void setRatingDirectory(RatingDirectory ratingDirectory) {
        this.ratingDirectory = ratingDirectory;
    }

    public float getEnvironment() {
        return environment;
    }

    public void setEnvironment(float environment) {
        this.environment = environment;
    }

    public float getService() {
        return service;
    }

    public void setService(float service) {
        this.service = service;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public float getFashion() {
        return fashion;
    }

    public void setFashion(float fashion) {
        this.fashion = fashion;
    }

    public float getPricing() {
        return pricing;
    }

    public void setPricing(float pricing) {
        this.pricing = pricing;
    }

    public float getRevenue() {
        return revenue;
    }

    public void setRevenue(float revenue) {
        this.revenue = revenue;
    }

    public Network getNetwork() {
        return network;
    }

    public void setNetwork(Network network) {
        this.network = network;
    }
    
    
    
    public Enterprise(String name,EnterpriseType type){
        super(name);
        this.enterpriseType=type;
        organizationDirectory=new OrganizationDirectory();
        lineList=new LineDirectory();
        stopList=new StopDirectory();
        customerDirectory=new CustomerDirectory();
        customerAccountDirectory=new CustomerAccountDirectory();
        ratingDirectory=new RatingDirectory();
        manufactureRequestList = new ManufactureRequestList();
    }
    
}
