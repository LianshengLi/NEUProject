/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Ticket;

import Business.Line.Line;
import java.util.ArrayList;

/**
 *
 * @author lizhenhao
 */
public class TicketDirectory {
    
    private ArrayList<Ticket> ticketList;
    
    public TicketDirectory() {
        ticketList = new ArrayList<Ticket>();
    }

    public ArrayList<Ticket> getTicketList() {
        return ticketList;
    }

    public void setTicketList(ArrayList<Ticket> ticketList) {
        this.ticketList = ticketList;
    }
    
    public Ticket AddTicket(Line line) {
        Ticket ticket = new Ticket();
        ticketList.add(ticket);
        return ticket;
    }
    
    public void DeleteTicket(Ticket t) {
        ticketList.remove(t);
    }
    
}
