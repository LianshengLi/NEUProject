/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Ticket;

import Business.Line.Line;
import java.util.Date;

/**
 *
 * @author lizhenhao
 */
public class Ticket {
    
    private Line line;
    private Date date;
    private int ID;
    private static int Count = 1;
    
    public Ticket() {
        //this.line = line;
        date = new Date();
        ID = Count;
        Count++;
    }

    public Line getLine() {
        return line;
    }

    public void setLine(Line line) {
        this.line = line;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    @Override
    public String toString() {
        String ticketID = Integer.toString(ID);
        return ticketID;
    }
    
}
