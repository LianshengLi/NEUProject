/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Rating;

import Business.Customer.Customer;
import java.util.ArrayList;

/**
 *
 * @author zhouzhou
 */
public class RatingDirectory {
     private ArrayList<Rating> ratingList;

    public RatingDirectory() {
        ratingList = new ArrayList();
    }

    public ArrayList<Rating> getRatingList() {
        return ratingList;
    }
      public Rating createRating(Customer customer){
          Rating rating=new Rating(customer);
        
        
        ratingList.add(rating);
        return rating;
    }
     
}
