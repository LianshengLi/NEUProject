/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author raunak
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
      //  for(Organization o:organizationList){
        if (type.getValue().equals(Type.Operation.getValue())){
            for (Organization a: organizationList) {
                if (a.getName().equals("Operation Organization")) {
                    JOptionPane.showMessageDialog(null, "This organization is already existed");
                    return null;
                            
                }
            }
            organization = new OperationOrganization();
            
           /*   if(organization.equals(o))
               JOptionPane.showMessageDialog(null, "You can only add one organization in this type!"); 
            break;}*/
            organization.setName("Operation Organization");
            organizationList.add(organization);
        }
       // for(Organization o:organizationList){
            if (type.getValue().equals(Type.Maintenance.getValue())){
                for (Organization a: organizationList) {
                if (a.getName().equals("Maintenance Organization")) {
                    JOptionPane.showMessageDialog(null, "This organization is already existed");
                    return null;
                            
                }
            }
            organization = new MaintenanceOrganization();
        /*     if(organization.equals(o))
               JOptionPane.showMessageDialog(null, "You can only add one organization in this type!"); 
            break;}*/
            organization.setName("Maintenance Organization");
            organizationList.add(organization);
        }
            if (type.getValue().equals(Type.Manufacture.getValue())){
                for (Organization a: organizationList) {
                if (a.getName().equals("Manufacture Organization")) {
                    JOptionPane.showMessageDialog(null, "This organization is already existed");
                    return null;
                            
                }
            }
            organization = new ManifactureOrganization();
        /*     if(organization.equals(o))
               JOptionPane.showMessageDialog(null, "You can only add one organization in this type!"); 
            break;}*/
            organization.setName("Manufacture Organization");
            organizationList.add(organization);
        }
        return organization;
    }
}