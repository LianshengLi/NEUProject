/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Timer;

import Business.Line.Line;
import Business.Organization.ManifactureOrganization;
import Business.WorkQueue.ManufactureRequest;
import java.util.TimerTask;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 41882
 */
public class DeliveryTimerTask extends TimerTask{
    private Line line;
    private DefaultTableModel model;
    private ManifactureOrganization organization;
    public DeliveryTimerTask(Line line, DefaultTableModel model,ManifactureOrganization organization){
        this.line = line;
        this.model = model;
        this.organization = organization;
    }

    @Override
    public void run() {
        line.setStatus("Normal");
        JOptionPane.showMessageDialog(null, "Delivered");
        model.setRowCount(0);
        for(ManufactureRequest request: organization.getManufactureRequestList().getManufactureRequestList()){
           
            Object[] row = new Object[3];
            row[0]=request.getSender();
            row[1]=request.getLine();
            row[2]=request.getLine().getStatus();
            model.addRow(row);
        }
    
    }
}
