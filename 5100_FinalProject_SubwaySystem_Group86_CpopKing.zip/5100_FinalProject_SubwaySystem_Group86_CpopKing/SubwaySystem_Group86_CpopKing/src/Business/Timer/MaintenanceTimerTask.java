/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Timer;

import Business.Organization.MaintenanceOrganization;
import Business.Stop.Stop;
import Business.WorkQueue.MaintenanceRequest;
import java.util.TimerTask;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 41882
 */
public class MaintenanceTimerTask extends TimerTask{
    private Stop stop;
    private DefaultTableModel model;
    private MaintenanceOrganization organization;
    private MaintenanceRequest request;
    //private int i;
    public MaintenanceTimerTask(Stop stop,DefaultTableModel model, MaintenanceOrganization organization, MaintenanceRequest request){
        this.stop = stop;
        this.model = model;
        this.organization=organization;
        this.request = request;
    }
    @Override
    public void run() {
        stop.setStatus("Normal");
        JOptionPane.showMessageDialog(null, "Finished");
        organization.getMaintenanceRequestList().getMaintenanceRequestList().remove(request);
        model.setRowCount(0);
        for(MaintenanceRequest request: organization.getMaintenanceRequestList().getMaintenanceRequestList()){
            Object[] row = new Object[4];
            row[0]=request.getSender().getEmployee().getName();
            row[1]=request.getStop();
            row[2]=request;
            row[3]=request.getStop().getStatus();
            model.addRow(row);
        }
    
    }
}