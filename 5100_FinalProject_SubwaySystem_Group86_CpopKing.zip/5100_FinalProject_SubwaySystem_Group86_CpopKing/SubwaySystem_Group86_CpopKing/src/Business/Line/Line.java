/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Line;

import Business.Stop.Stop;
import Business.Stop.StopDirectory;

/**
 *
 * @author zhouzhou
 */
public class Line {
      private String name;
      private String status="Needing Train";
      private Stop stop1;
      private Stop stop2;
      private Stop stop3;
      private Stop stop4;
      private Stop stop5;
      private float  price;
      
      public Line(String name){
          this.name=name;
      }
      
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Stop getStop1() {
        return stop1;
    }

    public void setStop1(Stop stop1) {
        this.stop1 = stop1;
    }

    public Stop getStop2() {
        return stop2;
    }

    public void setStop2(Stop stop2) {
        this.stop2 = stop2;
    }

    public Stop getStop3() {
        return stop3;
    }

    public void setStop3(Stop stop3) {
        this.stop3 = stop3;
    }

    public Stop getStop4() {
        return stop4;
    }

    public void setStop4(Stop stop4) {
        this.stop4 = stop4;
    }

    public Stop getStop5() {
        return stop5;
    }

    public void setStop5(Stop stop5) {
        this.stop5 = stop5;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

  
    
    
    @Override
    public String toString() {
        return name;
    }
    
}
